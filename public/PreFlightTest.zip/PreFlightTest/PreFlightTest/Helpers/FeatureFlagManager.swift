import Foundation

// Build-time feature flags.
// RELEASE_FEATURES is defined in Configuration/Release.xcconfig via OTHER_SWIFT_FLAGS.
// Debug builds do NOT define RELEASE_FEATURES, so those branches are never compiled in.
struct FeatureFlagManager {

    // Issue #16 (complex): When true, ProjectReminderService requests "Always" location auth.
    // The Info.plist key NSLocationAlwaysAndWhenInUseUsageDescription is missing.
    // This flag is ONLY true in Release builds, masking the problem during development.
    static var enableGeoReminders: Bool {
        #if RELEASE_FEATURES
        return true
        #else
        return false
        #endif
    }

    // When true, AnalyticsManager sends enriched user behavior data.
    // In Release builds, this includes IDFA and device fingerprint.
    static var enableAdvancedAnalytics: Bool {
        #if RELEASE_FEATURES
        return true
        #else
        return false
        #endif
    }

    // False positive trap: this flag only controls visual animations — no permissions,
    // no data collection. An analyzer that flags every RELEASE_FEATURES branch as
    // suspicious would produce a false positive here.
    static var enableAnimatedOnboarding: Bool {
        #if RELEASE_FEATURES
        return true
        #else
        return true  // also true in debug for development preview
        #endif
    }

    // User preference — not a build-time flag
    static var enableBiometricVault: Bool {
        UserDefaults.standard.bool(forKey: "biometricVaultEnabled")
    }
}
