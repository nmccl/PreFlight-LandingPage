import Foundation
import HealthKit

// False positive trap (Issue #14 companion):
// HealthKit is imported and the entitlement is declared in MyApp.entitlements,
// but this file performs NO health data queries or HKHealthStore reads/writes.
// This is a stub for a planned "activity gamification" feature that was never implemented.
//
// A naive analyzer might flag HealthKit usage purely because the entitlement exists.
// A strong analyzer should verify that HKHealthStore.requestAuthorization or any
// HKQuery is actually called before treating this as active HealthKit usage.
struct HealthDataBridge {

    // Only checks availability — does not request authorization or read data
    static var isHealthKitAvailable: Bool {
        HKHealthStore.isHealthDataAvailable()
    }

    // Placeholder — never called from any production code path
    static func fetchStepCountIfAvailable() async throws -> Double? {
        // TODO: Implement when feature is prioritized
        // Would require HKHealthStore.requestAuthorization(toShare:read:)
        // and NSHealthUpdateUsageDescription / NSHealthShareUsageDescription in Info.plist
        return nil
    }
}
