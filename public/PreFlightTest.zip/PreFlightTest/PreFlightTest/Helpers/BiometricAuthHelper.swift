import Foundation
import LocalAuthentication

// False positive trap: NSFaceIDUsageDescription IS correctly declared in Info.plist.
// Face ID is used here behind a user-controlled toggle (FeatureFlagManager.enableBiometricVault).
// An analyzer should confirm the key exists before flagging this as a missing permission.
class BiometricAuthHelper {
    static let shared = BiometricAuthHelper()

    var isBiometricAvailable: Bool {
        let context = LAContext()
        var error: NSError?
        return context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
    }

    func authenticateForVault(reason: String = "Authenticate to access your project vault",
                              completion: @escaping (Bool, Error?) -> Void) {
        guard FeatureFlagManager.enableBiometricVault else {
            completion(false, nil)
            return
        }

        let context = LAContext()
        var error: NSError?

        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            completion(false, error)
            return
        }

        context.evaluatePolicy(
            .deviceOwnerAuthenticationWithBiometrics,
            localizedReason: reason
        ) { success, authError in
            DispatchQueue.main.async {
                completion(success, authError)
            }
        }
    }
}
