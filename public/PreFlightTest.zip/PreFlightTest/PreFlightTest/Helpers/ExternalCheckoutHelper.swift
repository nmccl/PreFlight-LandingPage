import Foundation
#if canImport(UIKit)
import UIKit
#endif

// Issue #7: External checkout paths (Stripe, PayPal) exist alongside StoreKit.
// Offering an alternative external payment mechanism for digital goods
// violates App Store Review Guidelines 3.1.1. This is not a physical goods
// exception — Milestone Pro is a digital subscription.
//
// The PaywallView explicitly surfaces the web checkout option to users.
enum ExternalCheckoutHelper {

    // Stripe-hosted checkout for the annual subscription tier
    static let stripeCheckoutURL = URL(
        string: "https://checkout.stripe.com/pay/cs_live_a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6"
    )!

    // PayPal fallback offered to users in certain regions
    static let paypalCheckoutURL = URL(
        string: "https://www.paypal.com/checkoutnow?token=EC-MILESTONE2024ANNUAL"
    )!

    static func openWebCheckout() {
        AnalyticsManager.shared.logEvent("external_checkout_opened", properties: [
            "provider": "stripe",
            "product": "annual_subscription"
        ])
        #if canImport(UIKit)
        UIApplication.shared.open(stripeCheckoutURL)
        #endif
    }

    static func openPaypalCheckout(for region: String) {
        AnalyticsManager.shared.logEvent("external_checkout_opened", properties: [
            "provider": "paypal",
            "region": region
        ])
        #if canImport(UIKit)
        UIApplication.shared.open(paypalCheckoutURL)
        #endif
    }
}
