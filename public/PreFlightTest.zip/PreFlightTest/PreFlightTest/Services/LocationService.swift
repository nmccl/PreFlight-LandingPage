import Foundation
import Combine
import CoreLocation

class LocationService: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = LocationService()

    @Published var currentLocation: CLLocation?
    @Published var authorizationStatus: CLAuthorizationStatus = .notDetermined

    private let manager = CLLocationManager()

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
    }

    // Used by default flow and onboarding
    func requestWhenInUseAuthorization() {
        manager.requestWhenInUseAuthorization()
    }

    // Called by ProjectReminderService when FeatureFlagManager.enableGeoReminders is true.
    // This requires NSLocationAlwaysAndWhenInUseUsageDescription in Info.plist.
    // That key is MISSING — see the complex cross-file issue in ProjectReminderService.swift.
    func requestAlwaysAuthorization() {
        manager.requestAlwaysAuthorization()
    }

    func startUpdatingLocation() {
        manager.startUpdatingLocation()
    }

    func startMonitoringRegion(for coordinate: CLLocationCoordinate2D, identifier: String) {
        guard CLLocationManager.isMonitoringAvailable(for: CLCircularRegion.self) else { return }
        let region = CLCircularRegion(center: coordinate, radius: 200, identifier: identifier)
        region.notifyOnEntry = true
        region.notifyOnExit = false
        manager.startMonitoring(for: region)
    }

    // MARK: - CLLocationManagerDelegate

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        currentLocation = locations.last
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorizationStatus = manager.authorizationStatus
    }

    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        AnalyticsManager.shared.logEvent("geo_fence_entered", properties: ["region_id": region.identifier])
    }
}
