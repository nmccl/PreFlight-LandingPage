import Foundation
#if canImport(UIKit)
import UIKit
#endif

// Third-party SDK integrations (see Package.swift and GoogleService-Info.plist):
//   • Firebase Analytics  — com.google.firebase:firebase-analytics
//   • Mixpanel            — com.mixpanel.mixpanel-swift
//   • RevenueCat          — com.revenuecat.purchases-ios
//
// Issue #4: These SDKs collect behavioral, purchase, and device data.
// The App Store Connect privacy declaration for this app lists NO collected data types.
// The PrivacyInfo.xcprivacy NSPrivacyCollectedDataTypes array is also empty.
class AnalyticsManager {
    static let shared = AnalyticsManager()

    // Firebase — populated from GoogleService-Info.plist at runtime
    private let firebaseAppID = "1:123456789012:ios:abcdef1234567890abcdef"

    // Mixpanel project token
    private let mixpanelToken = "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4"

    // RevenueCat API key
    private let revenueCatAPIKey = "appl_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdef"

    func configure() {
        // FirebaseApp.configure()       ← requires GoogleService-Info.plist
        // Mixpanel.initialize(token:)
        // Purchases.configure(withAPIKey:)

        // Session tracking — ProcessInfo.processInfo.systemUptime is a Required Reason API
        // (NSPrivacyAccessedAPICategorySystemBootTime) — NOT declared in PrivacyInfo.xcprivacy
        let uptime = ProcessInfo.processInfo.systemUptime
        let sessionStart = Date().timeIntervalSince1970 - uptime
        UserDefaults.standard.set(sessionStart, forKey: "sessionStartTime")
        UserDefaults.standard.set(UUID().uuidString, forKey: "sessionId")

        UserDefaults.standard.set(firebaseAppID, forKey: "FIRInstanceID")
        UserDefaults.standard.set(true, forKey: "com.firebase.analytics.enabled")
    }

    func logScreen(_ screenName: String) {
        // Firebase: Analytics.logEvent(AnalyticsEventScreenView, parameters: [...])
        // Mixpanel: Mixpanel.mainInstance().track(event: "screen_view", ...)
        trackEvent("screen_view", properties: ["screen_name": screenName])
    }

    func logEvent(_ name: String, properties: [String: Any] = [:]) {
        trackEvent(name, properties: properties)
    }

    func logPurchase(productID: String, revenue: Double) {
        // Firebase: Analytics.logEvent(AnalyticsEventPurchase, parameters: [...])
        // RevenueCat: Purchases.shared.logIncome(...)
        trackEvent("purchase", properties: [
            "product_id": productID,
            "revenue": revenue,
            "currency": "USD"
        ])
    }

    // Issue #4 continued: enriches every event with device/user identifiers.
    // This constitutes data collection that requires App Store privacy disclosure.
    private func trackEvent(_ name: String, properties: [String: Any]) {
        var enriched = properties
        enriched["user_id"] = UserDefaults.standard.string(forKey: "userId") ?? "anonymous"
        enriched["session_id"] = UserDefaults.standard.string(forKey: "sessionId")
        enriched["app_version"] = Bundle.main.infoDictionary?["CFBundleShortVersionString"]
        enriched["idfa"] = TrackingManager.shared.advertisingIdentifierString

        #if canImport(UIKit)
        // Collects device model and OS version — requires privacy disclosure
        enriched["device_model"] = UIDevice.current.model
        enriched["os_version"] = UIDevice.current.systemVersion
        #else
        enriched["os_version"] = ProcessInfo.processInfo.operatingSystemVersionString
        #endif

        // In production: forward to Firebase endpoint + Mixpanel ingestion API
        print("[Analytics] \(name): \(enriched)")
    }
}
