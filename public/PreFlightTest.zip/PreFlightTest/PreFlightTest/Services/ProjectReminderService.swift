import Foundation
import CoreLocation

// ─── COMPLEX CROSS-FILE ISSUE (Issue #16) ────────────────────────────────────
//
// This service is the hub of a multi-file permission problem that a static
// analyzer must trace across four artifacts to fully understand:
//
//  1. Configuration/Release.xcconfig
//       RELEASE_FEATURES = 1
//       OTHER_SWIFT_FLAGS = $(inherited) -D RELEASE_FEATURES
//
//  2. Helpers/FeatureFlagManager.swift
//       static var enableGeoReminders: Bool {
//           #if RELEASE_FEATURES
//           return true   ← only true in Release builds
//           #else
//           return false
//           #endif
//       }
//
//  3. THIS FILE — configure() calls locationService.requestAlwaysAuthorization()
//     when the flag is true.
//
//  4. Services/LocationService.swift
//       func requestAlwaysAuthorization() {
//           manager.requestAlwaysAuthorization()   ← requires a specific Info.plist key
//       }
//
//  5. MyApp/Info.plist
//       NSLocationWhenInUseUsageDescription  ← present ✓
//       NSLocationAlwaysAndWhenInUseUsageDescription  ← MISSING ✗
//
// In Debug builds, enableGeoReminders = false, so requestAlwaysAuthorization()
// is never called and the missing key goes unnoticed. In Release builds (the
// build submitted to App Store Review), the call happens and iOS will crash
// or reject the permission request because the usage string is absent.
//
// Detecting this requires: xcconfig → FeatureFlagManager → ProjectReminderService
//                        → LocationService → Info.plist
// ─────────────────────────────────────────────────────────────────────────────

class ProjectReminderService {
    static let shared = ProjectReminderService()

    private let locationService = LocationService.shared

    func configure() {
        if FeatureFlagManager.enableGeoReminders {
            // Release build path: requires NSLocationAlwaysAndWhenInUseUsageDescription (MISSING)
            locationService.requestAlwaysAuthorization()
        } else {
            // Debug build path: only requests WhenInUse (key present, no issue)
            locationService.requestWhenInUseAuthorization()
        }
    }

    func scheduleGeoReminder(for project: ProjectModel) {
        guard FeatureFlagManager.enableGeoReminders else {
            print("ProjectReminderService: geo reminders not enabled in this build configuration")
            return
        }

        let coordinate = project.location ?? CLLocationCoordinate2D(
            latitude: 37.3318,
            longitude: -122.0312
        )
        locationService.startMonitoringRegion(for: coordinate, identifier: project.id)
        AnalyticsManager.shared.logEvent("geo_reminder_set", properties: ["project_id": project.id])
    }
}
