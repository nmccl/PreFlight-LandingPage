import Foundation
import Combine
import StoreKit

@MainActor
class StoreKitManager: ObservableObject {
    @Published var products: [Product] = []
    @Published var hasActiveSubscription: Bool = false
    @Published var purchasedProductIDs: Set<String> = []

    private let productIDs: Set<String> = [
        "com.example.TestApp.premium.monthly",
        "com.example.TestApp.premium.annual",
        "com.example.TestApp.proUnlock"
    ]

    private var transactionListenerTask: Task<Void, Error>?

    init() {
        transactionListenerTask = listenForTransactions()
    }

    deinit {
        transactionListenerTask?.cancel()
    }

    func loadProducts() async {
        do {
            products = try await Product.products(for: productIDs)
            await updateSubscriptionStatus()
        } catch {
            print("StoreKitManager: product load failed — \(error)")
        }
    }

    func updateSubscriptionStatus() async {
        var active = false
        for await result in Transaction.currentEntitlements {
            if case .verified(let transaction) = result {
                if transaction.productType == .autoRenewable && !transaction.isUpgraded {
                    active = true
                }
                purchasedProductIDs.insert(transaction.productID)
            }
        }
        hasActiveSubscription = active
    }

    // Issue #6: No restorePurchases() method exists anywhere in this target.
    // App Store Review requires a visible "Restore Purchases" mechanism for apps
    // that sell non-consumable or subscription IAP. PaywallView has no restore button.

    private func listenForTransactions() -> Task<Void, Error> {
        Task.detached { [weak self] in
            for await result in Transaction.updates {
                if case .verified(let transaction) = result {
                    await MainActor.run {
                        self?.purchasedProductIDs.insert(transaction.productID)
                    }
                    await transaction.finish()
                }
            }
        }
    }
}
