import Foundation
import Combine
import AVFoundation

// Issue #2: NSMicrophoneUsageDescription is MISSING from Info.plist.
// AVAudioRecorder requires this key at runtime on iOS — the app will crash
// when the system prompts for microphone access without the usage string.
// This is not behind a feature flag; VoiceNoteView calls startRecording() directly.
class AudioRecorderService: NSObject, ObservableObject {
    @Published var isRecording = false
    @Published var lastRecordingURL: URL?

    private var audioRecorder: AVAudioRecorder?

    func startRecording() {
        let outputURL = makeRecordingURL()

        let settings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 44_100,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]

        do {
            #if os(iOS)
            // AVAudioSession is iOS-only; macOS uses a different audio session model
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playAndRecord, mode: .default, options: .defaultToSpeaker)
            try audioSession.setActive(true)
            #endif

            audioRecorder = try AVAudioRecorder(url: outputURL, settings: settings)
            audioRecorder?.delegate = self
            audioRecorder?.record()
            isRecording = true

            AnalyticsManager.shared.logEvent("voice_note_started")
        } catch {
            print("AudioRecorderService: start failed — \(error.localizedDescription)")
        }
    }

    func stopRecording() {
        audioRecorder?.stop()
        #if os(iOS)
        try? AVAudioSession.sharedInstance().setActive(false)
        #endif
        isRecording = false
        lastRecordingURL = audioRecorder?.url

        // FileManager.attributesOfItem accesses file timestamps —
        // NSPrivacyAccessedAPICategoryFileTimestamp should be declared in PrivacyInfo.xcprivacy.
        if let url = lastRecordingURL,
           let attrs = try? FileManager.default.attributesOfItem(atPath: url.path) {
            let size = attrs[.size] as? Int ?? 0
            AnalyticsManager.shared.logEvent("voice_note_saved", properties: ["bytes": size])
        }
    }

    private func makeRecordingURL() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("note_\(Date().timeIntervalSince1970).m4a")
    }
}

extension AudioRecorderService: AVAudioRecorderDelegate {
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        isRecording = false
    }

    func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
        isRecording = false
        print("AudioRecorderService: encode error — \(error?.localizedDescription ?? "unknown")")
    }
}
