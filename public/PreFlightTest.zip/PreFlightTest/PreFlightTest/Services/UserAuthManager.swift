import Foundation
import Combine

// Issue #15: Login-gated features (team collaboration) exist but no demo
// credentials are provided in review_notes.txt or anywhere in the project.
// An App Reviewer who reaches the team features cannot proceed without an account.
@MainActor
class UserAuthManager: ObservableObject {
    @Published var isLoggedIn: Bool = false
    @Published var currentUser: UserModel?

    func signIn(email: String, password: String) async {
        do {
            let user = try await NetworkManager.shared.login(email: email, password: password)
            currentUser = user
            isLoggedIn = true
            UserDefaults.standard.set(user.id, forKey: "userId")
            AnalyticsManager.shared.logEvent("user_signed_in", properties: [
                "method": "email",
                "is_premium": user.isPremium
            ])
        } catch {
            // Sign in failed — leave isLoggedIn = false
            print("UserAuthManager: sign in error — \(error.localizedDescription)")
        }
    }

    // Allows skipping authentication — team features will be inaccessible
    func skipLogin() {
        isLoggedIn = true
        currentUser = nil
        AnalyticsManager.shared.logEvent("login_skipped")
    }

    func signOut() {
        currentUser = nil
        isLoggedIn = false
        UserDefaults.standard.removeObject(forKey: "userId")
        AnalyticsManager.shared.logEvent("user_signed_out")
    }

    // Team features require an authenticated user with a teamID.
    // Reviewers cannot access this without credentials (Issue #8).
    var canAccessTeamFeatures: Bool {
        isLoggedIn && currentUser?.teamID != nil
    }
}
