import Foundation

class NetworkManager {
    static let shared = NetworkManager()

    private let baseURL = "https://api.milestonetasks.app/v1"

    func login(email: String, password: String) async throws -> UserModel {
        guard let url = URL(string: "\(baseURL)/auth/login") else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: String] = ["email": email, "password": password]
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }

        return try JSONDecoder().decode(UserModel.self, from: data)
    }

    func fetchProjects(userID: String) async throws -> [ProjectModel] {
        guard let url = URL(string: "\(baseURL)/users/\(userID)/projects") else {
            throw URLError(.badURL)
        }
        let (data, _) = try await URLSession.shared.data(from: url)
        return try JSONDecoder().decode([ProjectModel].self, from: data)
    }

    func createProject(_ project: ProjectModel, userID: String) async throws -> ProjectModel {
        guard let url = URL(string: "\(baseURL)/projects") else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(project)

        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode(ProjectModel.self, from: data)
    }
}
