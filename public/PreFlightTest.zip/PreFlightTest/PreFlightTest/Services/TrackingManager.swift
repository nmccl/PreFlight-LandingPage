import Foundation
#if canImport(AppTrackingTransparency)
import AppTrackingTransparency
#endif
#if canImport(AdSupport)
import AdSupport
#endif

// Issue #5: NSPrivacyTracking is set to false in PrivacyInfo.xcprivacy,
// AND NSPrivacyTrackingDomains lists Firebase + Mixpanel domains.
// These two declarations directly contradict each other.
// Additionally, this class actively collects the IDFA after ATT consent —
// which is tracking and must be declared as true.
class TrackingManager {
    static let shared = TrackingManager()

    private(set) var isTrackingAuthorized = false
    private var rawIDFA: UUID?

    func configure() {
        // Intentionally called from App.init() — before UI is ready.
        // ATT prompt must appear after the first launch screen; calling from init is incorrect.
        requestTrackingAuthorization()
    }

    func requestTrackingAuthorization() {
        #if canImport(AppTrackingTransparency)
        if #available(iOS 14, *) {
            ATTrackingManager.requestTrackingAuthorization { [weak self] status in
                DispatchQueue.main.async {
                    self?.handleStatus(status)
                }
            }
        }
        #endif
    }

    #if canImport(AppTrackingTransparency)
    @available(iOS 14, *)
    private func handleStatus(_ status: ATTrackingManager.AuthorizationStatus) {
        switch status {
        case .authorized:
            isTrackingAuthorized = true
            collectIDFA()
        case .denied, .restricted, .notDetermined:
            isTrackingAuthorized = false
        @unknown default:
            break
        }
    }
    #endif

    // Collects IDFA and forwards it to analytics — constitutes "tracking" per App Store rules.
    // NSPrivacyTracking must be true in PrivacyInfo.xcprivacy, but it is false.
    private func collectIDFA() {
        #if canImport(AdSupport)
        rawIDFA = ASIdentifierManager.shared().advertisingIdentifier
        if let idfa = rawIDFA {
            UserDefaults.standard.set(idfa.uuidString, forKey: "userIDFA")
        }
        #endif
    }

    // Exposed to AnalyticsManager for event enrichment
    var advertisingIdentifierString: String? {
        #if canImport(AdSupport)
        guard isTrackingAuthorized else { return nil }
        return rawIDFA?.uuidString ?? ASIdentifierManager.shared().advertisingIdentifier.uuidString
        #else
        return nil
        #endif
    }

    // False positive trap: this property correctly gates IDFA behind authorization.
    // An analyzer that only checks "ASIdentifierManager used" without verifying the
    // authorization guard would incorrectly flag this as unconditional IDFA collection.
    var safeAdvertisingIdentifier: UUID? {
        guard isTrackingAuthorized else { return nil }
        return rawIDFA
    }
}
