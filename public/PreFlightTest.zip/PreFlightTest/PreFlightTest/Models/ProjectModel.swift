import Foundation
import CoreLocation

struct ProjectModel: Identifiable, Codable {
    let id: String
    var name: String
    var description: String
    var dueDate: Date
    var tasks: [TaskItem]
    var locationLatitude: Double?
    var locationLongitude: Double?

    var location: CLLocationCoordinate2D? {
        get {
            guard let lat = locationLatitude, let lon = locationLongitude else { return nil }
            return CLLocationCoordinate2D(latitude: lat, longitude: lon)
        }
        set {
            locationLatitude = newValue?.latitude
            locationLongitude = newValue?.longitude
        }
    }

    var completionRatio: Double {
        guard !tasks.isEmpty else { return 0 }
        return Double(tasks.filter { $0.isCompleted }.count) / Double(tasks.count)
    }

    static let sampleData: [ProjectModel] = [
        ProjectModel(
            id: "proj-001",
            name: "Website Redesign",
            description: "Complete overhaul of the company site with new brand guidelines.",
            dueDate: Date().addingTimeInterval(86_400 * 14),
            tasks: [
                TaskItem(id: "t1", title: "Wireframes", isCompleted: true, assignee: "Alice"),
                TaskItem(id: "t2", title: "Design mockups", isCompleted: true, assignee: "Bob"),
                TaskItem(id: "t3", title: "Frontend development", isCompleted: false, assignee: "Alice"),
                TaskItem(id: "t4", title: "QA testing", isCompleted: false, assignee: nil)
            ]
        ),
        ProjectModel(
            id: "proj-002",
            name: "Mobile App v2.0",
            description: "Feature update introducing subscription tiers and analytics.",
            dueDate: Date().addingTimeInterval(86_400 * 30),
            tasks: [
                TaskItem(id: "t5", title: "StoreKit integration", isCompleted: true, assignee: "Charlie"),
                TaskItem(id: "t6", title: "Analytics setup", isCompleted: false, assignee: "Charlie"),
                TaskItem(id: "t7", title: "Beta testing", isCompleted: false, assignee: nil)
            ]
        ),
        ProjectModel(
            id: "proj-003",
            name: "Q4 Marketing Campaign",
            description: "End-of-year campaign across social and email channels.",
            dueDate: Date().addingTimeInterval(86_400 * 7),
            tasks: [
                TaskItem(id: "t8", title: "Copy writing", isCompleted: false, assignee: "Diana"),
                TaskItem(id: "t9", title: "Asset creation", isCompleted: false, assignee: nil)
            ]
        )
    ]
}

struct TaskItem: Identifiable, Codable {
    let id: String
    var title: String
    var isCompleted: Bool
    var assignee: String?
}
