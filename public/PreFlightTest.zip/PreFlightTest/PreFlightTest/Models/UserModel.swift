import Foundation

struct UserModel: Codable, Identifiable {
    let id: String
    let email: String
    let displayName: String
    var isPremium: Bool
    var teamID: String?

    // Issue #15: Team features are gated on `teamID != nil`.
    // There is no way to obtain a teamID without a real account.
    // No demo credentials are provided anywhere in the project (Issue #8).

    // False positive trap: this static string is NOT a hardcoded credential.
    // It is a documentation note surfaced to the UI for guest users.
    static let teamFeatureUpsellMessage = "Join or create a team to collaborate on projects in real time."
}

// Thin wrapper for the auth token — persisted in UserDefaults (not Keychain).
// This is a real security concern but outside PreFlight's permission/metadata scope.
struct AuthToken: Codable {
    let accessToken: String
    let refreshToken: String
    let expiresAt: Date

    var isExpired: Bool { Date() > expiresAt }
}
