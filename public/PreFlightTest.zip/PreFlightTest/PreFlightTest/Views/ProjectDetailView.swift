import SwiftUI

struct ProjectDetailView: View {
    let project: ProjectModel
    @State private var showingVoiceNote = false
    @State private var showingReminderSheet = false
    @State private var completionProgress: Double = 0

    var body: some View {
        List {
            Section("Overview") {
                VStack(alignment: .leading, spacing: 8) {
                    Text(project.name)
                        .font(.title2.bold())
                    Text(project.description)
                        .foregroundStyle(.secondary)
                }

                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(NSLocalizedString("project.progress", comment: ""))
                        Spacer()
                        Text("\(Int(completionProgress * 100))%")
                            .foregroundStyle(.secondary)
                    }
                    // Issue #9: Progress animation does not check @Environment(\.accessibilityReduceMotion)
                    ProgressView(value: completionProgress)
                        .animation(.spring(response: 1.2, dampingFraction: 0.7), value: completionProgress)
                }
                .onAppear {
                    withAnimation(.spring(response: 1.2, dampingFraction: 0.7)) {
                        completionProgress = project.completionRatio
                    }
                }
            }

            Section(NSLocalizedString("project.tasks", comment: "")) {
                ForEach(project.tasks) { task in
                    TaskRowView(task: task)
                }
            }

            Section(NSLocalizedString("project.actions", comment: "")) {
                Button(action: { showingVoiceNote = true }) {
                    Label(
                        NSLocalizedString("project.voice_note", comment: ""),
                        systemImage: "mic"
                    )
                }
                Button(action: { showingReminderSheet = true }) {
                    Label(
                        NSLocalizedString("project.geo_reminder", comment: ""),
                        systemImage: "location"
                    )
                }
            }
        }
        .navigationTitle(project.name)
        .sheet(isPresented: $showingVoiceNote) {
            VoiceNoteView()
        }
        .confirmationDialog("Set Reminder", isPresented: $showingReminderSheet) {
            Button("When I arrive at a location") {
                ProjectReminderService.shared.scheduleGeoReminder(for: project)
            }
            Button("At a specific time") { }
            Button("Cancel", role: .cancel) { }
        }
        .onAppear {
            AnalyticsManager.shared.logScreen("project_detail")
        }
    }
}

struct TaskRowView: View {
    let task: TaskItem

    var body: some View {
        HStack(spacing: 12) {
            // Issue #9: Tappable image with no accessibility label or .button trait.
            // VoiceOver cannot describe this control or its purpose.
            Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(task.isCompleted ? .green : .secondary)
                .font(.title3)
                .onTapGesture { /* toggle would go here */ }

            VStack(alignment: .leading, spacing: 2) {
                Text(task.title)
                if let assignee = task.assignee {
                    Text(assignee)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }
}

struct VoiceNoteView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var recorder = AudioRecorderService()

    var body: some View {
        VStack(spacing: 24) {
            Text("Voice Note")
                .font(.title2.bold())

            // Issue #9: Critical control with no accessibility label.
            // VoiceOver users cannot determine what this button does.
            Button(action: {
                if recorder.isRecording {
                    recorder.stopRecording()
                } else {
                    recorder.startRecording()
                }
            }) {
                Image(systemName: recorder.isRecording ? "stop.circle.fill" : "mic.circle.fill")
                    .font(.system(size: 72))
                    .foregroundStyle(recorder.isRecording ? .red : .accentColor)
            }
            // .accessibilityLabel intentionally omitted

            if recorder.isRecording {
                Text("Recording…")
                    .foregroundStyle(.red)
                    // Issue #9: Pulsing animation — no Reduce Motion check
                    .opacity(0.5)
                    .animation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: recorder.isRecording)
            }

            Button("Done") { dismiss() }
                .buttonStyle(.bordered)
        }
        .padding()
        .presentationDetents([.medium])
    }
}
