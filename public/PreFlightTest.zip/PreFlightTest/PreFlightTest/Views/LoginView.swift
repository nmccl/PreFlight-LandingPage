import SwiftUI

// Issue #8: App has a login-gated feature (team collaboration) but
// no demo account credentials are provided in review_notes.txt or elsewhere.
// An App Reviewer cannot access team features without credentials.
struct LoginView: View {
    @EnvironmentObject var authManager: UserAuthManager
    @State private var email = ""
    @State private var password = ""
    @State private var isLoading = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            Text(NSLocalizedString("login.title", comment: ""))
                .font(.largeTitle.bold())

            Text(NSLocalizedString("login.subtitle", comment: ""))
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal)

            VStack(spacing: 12) {
                // Issue #10: Email field is missing .keyboardType(.emailAddress)
                // Default keyboard (.default) does not optimize for email entry.
                TextField(NSLocalizedString("login.email", comment: ""), text: $email)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled()
                    // keyboardType intentionally omitted — should be .emailAddress (Issue #10)

                SecureField(NSLocalizedString("login.password", comment: ""), text: $password)
                    .textFieldStyle(.roundedBorder)
            }
            .padding(.horizontal)

            if let error = errorMessage {
                Text(error)
                    .foregroundStyle(.red)
                    .font(.caption)
            }

            Button(action: signIn) {
                if isLoading {
                    ProgressView()
                        .frame(maxWidth: .infinity)
                } else {
                    Text(NSLocalizedString("login.sign_in", comment: ""))
                        .frame(maxWidth: .infinity)
                }
            }
            .buttonStyle(.borderedProminent)
            .padding(.horizontal)
            .disabled(isLoading || email.isEmpty || password.isEmpty)

            Button(NSLocalizedString("login.continue_without", comment: "")) {
                authManager.skipLogin()
            }
            .foregroundStyle(.secondary)

            Spacer()
        }
        .onAppear {
            AnalyticsManager.shared.logScreen("login")
        }
    }

    private func signIn() {
        isLoading = true
        errorMessage = nil
        Task {
            await authManager.signIn(email: email, password: password)
            await MainActor.run {
                isLoading = false
                if !authManager.isLoggedIn {
                    errorMessage = "Invalid email or password."
                }
            }
        }
    }
}

#Preview {
    LoginView()
        .environmentObject(UserAuthManager())
}
