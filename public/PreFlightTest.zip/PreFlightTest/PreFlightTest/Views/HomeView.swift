import SwiftUI

struct HomeView: View {
    @EnvironmentObject var authManager: UserAuthManager
    @EnvironmentObject var storeKit: StoreKitManager
    @State private var projects: [ProjectModel] = ProjectModel.sampleData
    @State private var showingCamera = false
    @State private var showingSettings = false
    @State private var animateHeader = false

    var body: some View {
        List {
            Section {
                HStack {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                        // Issue #9: Spring animation with no Reduce Motion check
                        .scaleEffect(animateHeader ? 1.2 : 1.0)
                        .animation(
                            .spring(response: 0.3, dampingFraction: 0.6)
                                .repeatForever(autoreverses: true),
                            value: animateHeader
                        )
                    // Issue #9: Hard-coded font size — ignores Dynamic Type
                    Text("Active Projects")
                        .font(.system(size: 22, weight: .bold))
                }
                .onAppear { animateHeader = true }
            }

            ForEach(projects) { project in
                NavigationLink(destination: ProjectDetailView(project: project)) {
                    ProjectRowView(project: project)
                }
            }
        }
        .navigationTitle("Milestone")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                // Issue #9: Icon-only button — no accessibility label
                Button(action: { showingSettings = true }) {
                    Image(systemName: "gearshape")
                }
            }
            ToolbarItem(placement: .primaryAction) {
                // Issue #9: Icon-only button — no accessibility label
                Button(action: { showingCamera = true }) {
                    Image(systemName: "camera")
                }
            }
        }
        .sheet(isPresented: $showingCamera) {
            CameraView()
        }
        .sheet(isPresented: $showingSettings) {
            SettingsView()
                .environmentObject(authManager)
        }
        .onAppear {
            AnalyticsManager.shared.logScreen("home")
            ProjectReminderService.shared.configure()
        }
    }
}

struct ProjectRowView: View {
    let project: ProjectModel

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            // Issue #9: Fixed font size ignores Dynamic Type accessibility settings
            Text(project.name)
                .font(.system(size: 16, weight: .semibold))
            Text(project.dueDate, style: .date)
                .font(.system(size: 12))
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 2)
    }
}

#Preview {
    NavigationStack {
        HomeView()
            .environmentObject(UserAuthManager())
            .environmentObject(StoreKitManager())
    }
}
