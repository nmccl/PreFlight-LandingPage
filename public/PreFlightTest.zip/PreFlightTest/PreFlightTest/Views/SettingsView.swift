import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var authManager: UserAuthManager

    // Issue #13: Terms URL is intentionally empty/missing
    private let privacyURL = URL(string: "https://example.com/privacy")
    private let termsURLString = ""  // Missing — no Terms of Service URL configured
    private let supportURL = URL(string: "https://example.com/support")

    // False positive trap: URL contains the word "payment" but is a documentation link,
    // not an external payment endpoint.
    private let attributionURL = URL(string: "https://example.com/open-source-payment-libraries")

    var body: some View {
        NavigationStack {
            Form {
                Section("Account") {
                    if authManager.isLoggedIn, let user = authManager.currentUser {
                        HStack {
                            Text("Signed in as")
                            Spacer()
                            Text(user.email)
                                .foregroundStyle(.secondary)
                        }
                        Button("Sign Out", role: .destructive) {
                            authManager.signOut()
                        }
                    } else if authManager.isLoggedIn {
                        Text("Guest session")
                            .foregroundStyle(.secondary)
                        Button("Sign In") {
                            authManager.signOut() // force back to login
                        }
                    }
                }

                Section("Legal") {
                    if let url = privacyURL {
                        Link(NSLocalizedString("settings.privacy_policy", comment: ""), destination: url)
                    }

                    // Issue #13: Terms URL is empty — this control is non-functional
                    if !termsURLString.isEmpty, let url = URL(string: termsURLString) {
                        Link(NSLocalizedString("settings.terms", comment: ""), destination: url)
                    } else {
                        // Terms of Service link is intentionally broken/missing
                        Text(NSLocalizedString("settings.terms", comment: ""))
                            .foregroundStyle(.secondary)
                    }

                    if let url = supportURL {
                        Link("Support", destination: url)
                    }

                    // False positive trap: looks suspicious, is benign
                    if let url = attributionURL {
                        Link("Open Source Licenses", destination: url)
                    }
                }

                Section("About") {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Text("Build")
                        Spacer()
                        Text(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1")
                            .foregroundStyle(.secondary)
                    }
                }

                // False positive trap: This section only exists in DEBUG builds.
                // ATT reset here is a dev tool, not production tracking usage.
                #if DEBUG
                Section("Developer") {
                    Button("Simulate ATT Reset") {
                        print("DEBUG: ATT state would reset here")
                    }
                    Button("Clear Analytics Cache") {
                        UserDefaults.standard.removeObject(forKey: "sessionId")
                    }
                }
                #endif
            }
            .navigationTitle(NSLocalizedString("settings.title", comment: ""))
            .toolbar {
                ToolbarItem(placement: .automatic) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
