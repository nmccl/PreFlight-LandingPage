import SwiftUI
import StoreKit

struct PaywallView: View {
    @EnvironmentObject var storeKit: StoreKitManager
    @Environment(\.dismiss) private var dismiss
    @State private var isPurchasing = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(spacing: 24) {
            Text("Milestone Pro")
                .font(.largeTitle.bold())

            Text(NSLocalizedString("paywall.subtitle", comment: ""))
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal)

            if let monthly = storeKit.products.first(where: {
                $0.id == "com.example.TestApp.premium.monthly"
            }) {
                Button(action: { Task { await purchase(monthly) } }) {
                    VStack(spacing: 4) {
                        Text("Monthly")
                            .font(.headline)
                        Text(monthly.displayPrice + "/month")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.accentColor)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .disabled(isPurchasing)
            }

            if let annual = storeKit.products.first(where: {
                $0.id == "com.example.TestApp.premium.annual"
            }) {
                Button(action: { Task { await purchase(annual) } }) {
                    VStack(spacing: 4) {
                        Text("Annual — Save 40%")
                            .font(.headline)
                        Text(annual.displayPrice + "/year")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.accentColor.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .strokeBorder(Color.accentColor, lineWidth: 1)
                    )
                }
                .disabled(isPurchasing)
            }

            // Issue #6: Paywall has no "Restore Purchases" button anywhere.
            // App Review requires a visible restore mechanism for any app with IAP.

            if let error = errorMessage {
                Text(error)
                    .foregroundStyle(.red)
                    .font(.caption)
                    .multilineTextAlignment(.center)
            }

            // Issue #7: External payment path (Stripe) alongside StoreKit.
            // Offering an external checkout for digital content violates App Store guidelines.
            Button(NSLocalizedString("paywall.web_checkout", comment: "")) {
                ExternalCheckoutHelper.openWebCheckout()
            }
            .font(.footnote)
            .foregroundStyle(.secondary)

            Button(NSLocalizedString("paywall.later", comment: "")) {
                dismiss()
            }
            .foregroundStyle(.secondary)
        }
        .padding()
        .presentationDetents([.large])
        .onAppear {
            AnalyticsManager.shared.logScreen("paywall")
        }
    }

    private func purchase(_ product: Product) async {
        isPurchasing = true
        defer { isPurchasing = false }
        do {
            let result = try await product.purchase()
            switch result {
            case .success(let verification):
                let transaction = try checkVerified(verification)
                await transaction.finish()
                await storeKit.updateSubscriptionStatus()
                AnalyticsManager.shared.logPurchase(productID: product.id, revenue: NSDecimalNumber(decimal: product.price).doubleValue)
                dismiss()
            case .userCancelled:
                break
            case .pending:
                errorMessage = "Purchase is pending approval."
            @unknown default:
                break
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func checkVerified<T>(_ result: VerificationResult<T>) throws -> T {
        switch result {
        case .unverified:
            throw StoreError.failedVerification
        case .verified(let value):
            return value
        }
    }
}

enum StoreError: Error {
    case failedVerification
}
