import SwiftUI
import AVFoundation
#if canImport(UIKit)
import UIKit
#endif

// False positive trap: NSCameraUsageDescription IS correctly declared in Info.plist.
// Camera usage here is legitimate. An analyzer should not flag this as a missing permission.
struct CameraView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var hasPermission = false
    @State private var permissionDenied = false

    var body: some View {
        VStack(spacing: 20) {
            Text("Document Scanner")
                .font(.title2.bold())

            if hasPermission {
                Text("Camera preview")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color.secondary.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            } else if permissionDenied {
                VStack(spacing: 12) {
                    Image(systemName: "camera.fill")
                        .font(.system(size: 48))
                        .foregroundStyle(.secondary)
                    Text("Camera access is required to scan documents.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                    Button("Open Settings") {
                        openSystemSettings()
                    }
                    .buttonStyle(.bordered)
                }
                .padding()
            } else {
                ProgressView("Checking camera access…")
            }

            Button("Cancel") { dismiss() }
                .foregroundStyle(.secondary)
        }
        .padding()
        .task { await checkPermission() }
    }

    @MainActor
    private func checkPermission() async {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            hasPermission = true
        case .notDetermined:
            let granted = await AVCaptureDevice.requestAccess(for: .video)
            hasPermission = granted
            permissionDenied = !granted
        case .denied, .restricted:
            permissionDenied = true
        @unknown default:
            break
        }
    }

    private func openSystemSettings() {
        #if canImport(UIKit)
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
        #endif
    }
}
