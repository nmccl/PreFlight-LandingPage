import SwiftUI

@main
struct MilestoneApp: App {
    @StateObject private var authManager = UserAuthManager()
    @StateObject private var storeKit = StoreKitManager()

    init() {
        // ATT request called too early — before UI is presented (realistic indie dev mistake)
        TrackingManager.shared.configure()
        AnalyticsManager.shared.configure()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(authManager)
                .environmentObject(storeKit)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var authManager: UserAuthManager
    @EnvironmentObject var storeKit: StoreKitManager
    @State private var showingPaywall = false

    var body: some View {
        NavigationStack {
            if authManager.isLoggedIn {
                HomeView()
            } else {
                LoginView()
            }
        }
        .sheet(isPresented: $showingPaywall) {
            PaywallView()
        }
        .task {
            await storeKit.loadProducts()
            if !storeKit.hasActiveSubscription {
                showingPaywall = true
            }
        }
    }
}
